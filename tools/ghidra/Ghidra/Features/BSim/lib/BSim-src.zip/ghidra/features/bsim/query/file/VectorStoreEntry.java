/* ###
 * IP: GHIDRA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ghidra.features.bsim.query.file;

import generic.lsh.vector.LSHVector;

/**
 * A record containing an {@link LSHVector} and a count of the number of functions in the 
 * database which share the vector
 * @param id vector ID
 * @param vec vector
 * @param count count
 * @param selfSig self-significance of vector (using database settings)
 */
public record VectorStoreEntry(long id, LSHVector vec, int count, double selfSig) {
}
